-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2021 at 07:53 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sparks_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `sno` int(3) NOT NULL,
  `sender` text NOT NULL,
  `receiver` text NOT NULL,
  `balance` int(8) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`sno`, `sender`, `receiver`, `balance`, `datetime`) VALUES
(1, 'Hanu Shyn', 'Honey Isaac', 300, '2021-08-20 17:16:50'),
(2, 'Aarsh', 'Raju L', 10000, '2021-08-20 17:18:49'),
(3, 'Priya Roy', 'Jessi Emerald', 3000, '2021-08-20 17:19:17'),
(4, 'Kriti Sharma', 'Navya Verma', 2500, '2021-08-20 17:19:39'),
(5, 'Honey Isaac', 'Prashanth Gowda', 5000, '2021-08-20 17:20:08'),
(6, 'Honey Isaac', 'Naksha Tripati', 2500, '2021-08-20 17:20:38'),
(7, 'Priya Roy', 'Aarsh', 7000, '2021-08-20 17:21:21'),
(8, 'Hanu Shyn', 'Naksha Tripati', 6000, '2021-08-20 17:21:47'),
(9, 'Kriti Sharma', 'Raju L', 2500, '2021-08-20 17:22:38'),
(10, 'Navya Verma', 'Jessi Emerald', 2500, '2021-08-20 17:23:18'),
(11, 'Honey Isaac', 'Raju L', 5500, '2021-08-20 17:23:56'),
(12, 'Raju L', 'Jessi Emerald', 3000, '2021-08-20 17:24:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(3) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `balance` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `balance`) VALUES
(1, 'Priya Roy', 'priya@gmail.com', 40000),
(2, 'Kriti Sharma', 'kriti@gmail.com', 40000),
(3, 'Navya Verma', 'navya@gmail.com', 40000),
(4, 'Prashanth Gowda', 'prashanth@gmail.com', 40000),
(5, 'Aarsh', 'aarsh@gmail.com', 41000),
(6, 'Raju L', 'raju24@gmail.com', 40000),
(7, 'Honey Isaac', 'honey2002@gmail.com', 40000),
(8, 'Jessi Emerald', 'jessi14@gmail.com', 40500),
(9, 'Naksha Tripati', 'naksha@gmail.com', 40000),
(10, 'Hanu Shyn', 'hanu2414@gmail.com', 40600);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `sno` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
