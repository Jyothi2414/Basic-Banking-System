<?php include('nav.php') ?>


  <h1>Welcome to Sparks Foundation </h1>


  <div class="bg">
    <div class="center">
      <ul>
        <li class="operations"><a href="users.php"><button class="btn" id="one"><b> Users </b></button></a></li>
        <li class="operations"><a href="transfer_money.php"><button class="btn" id="two"><b> Money Trasnfer </b></button></a></li>
        <li class="operations"><a href="transactionhistory.php"><button class="btn" id="three"><b> Transaction History </b></button></a></li>
      </ul>
    </div>
  </div>

  <?php include('footer.php') ?>
  
</body>
</html>