<div class="footer">
    <center> <h5><b> Contact us </b></h5> 
   
     
    <b> sparksbank@gmail.com <br>
      080 22113344 , +919876543210 <br>
       The Sparks Foundation Bank </b> </center>
 </div>
</div>
